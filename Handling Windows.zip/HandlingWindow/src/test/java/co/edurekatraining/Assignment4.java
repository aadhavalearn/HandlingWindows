package co.edurekatraining;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Assignment4 {

    WebDriver driver;

    @BeforeMethod
    public void setUp() {
        // Setting up chrome WebDriver
        System.setProperty("webdriver.chrome.driver", "D:\\Automation\\Drivers\\chromedriver.exe");
        driver = new ChromeDriver();
        ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.addArguments("--remote-allow-origins=*");
        ChromeDriver driver = new ChromeDriver(chromeOptions);
        driver.manage().window().maximize();
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test
    public void testRediffSignInAlert() throws InterruptedException {
        // Step 1: Launch Rediff website and click on Sign In
        driver.get("https://www.rediff.com/");
        driver.findElement(By.xpath("//a[contains(text(),'Sign in')]")).click();

        // Step 2: Click on Sign in button without entering username and password
        driver.findElement(By.name("proceed")).click();
        
        // Step 3: Handle the alert and validate its message
        Alert alert = driver.switchTo().alert();
        String alertMessage = alert.getText();
        System.out.println("Alert message: " + alertMessage);

        // Validate the alert message (Assume the message is "Please enter a valid user name")
        Assert.assertEquals(alertMessage, "Please enter a valid user name");

        // Close the alert
        alert.accept();

        // Optional wait for visibility (for demo purposes)
        Thread.sleep(2000);
    }

    @Test
    public void testMultipleWindows() throws InterruptedException {
        // Step 4: Launch DemoQA Browser Windows page
        driver.get("https://demoqa.com/browser-windows");

        // Step 5: Click on New Tab, New Window, New Window Message
        driver.findElement(By.id("tabButton")).click(); // New Tab
        driver.findElement(By.id("windowButton")).click(); // New Window
        driver.findElement(By.id("messageWindowButton")).click(); // New Window Message

        // Step 6: Get the list of window handles
        Set<String> windowHandles = driver.getWindowHandles();
        System.out.println("Window Handles:");
        for (String handle : windowHandles) {
            System.out.println(handle);
        }

        // Step 7: Print the total window count size
        int windowCount = windowHandles.size();
        System.out.println("Total number of windows/tabs opened: " + windowCount);
        Assert.assertTrue(windowHandles.size() > 1, "Multiple windows should be opened.");

        // Validate if window handles are unique
        Assert.assertEquals(windowHandles.size(), windowHandles.stream().distinct().count(), "Window handles should be unique.");

        // Switch to each window and print the title for demo purposes
        Iterator<String> iterator = windowHandles.iterator();
        while (iterator.hasNext()) {
            String handle = iterator.next();
            driver.switchTo().window(handle);
            System.out.println("Window Title: " + driver.getTitle());
        }

        // Optional wait for visibility (for demo purposes)
        Thread.sleep(2000);
    }
}
